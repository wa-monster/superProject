import EnclosureHttp from "./core"
export const http = new EnclosureHttp()

