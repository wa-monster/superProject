<template>
  <div class="welcome">
    <el-affix>
      <div class="top-content">
        <div class="left-mark">
          <img src="https://avatars.githubusercontent.com/u/44761321?s=400&u=30907819abd29bb3779bc247910873e7c7f7c12f&v=4" title="直达仓库地址" alt @click="openDepot" />
          <span>{{ greetings }}</span>
        </div>
        <Flop v-if="!mobile" />
      </div>
    </el-affix>
  </div>
</template>

<script lang="ts">
import Flop from "/@/components/Flop"
import { ref, computed, onMounted, nextTick } from "vue"
import { deviceDetection } from "/@/utils/deviceDetection"
import { useEventListener, tryOnUnmounted, useTimeoutFn } from "@vueuse/core"
import echarts from "/@/plugins/echarts"

let brokenLine: any = null //折线图实例
export default {
  name: "welcome",
  components: {
    Flop,
  },
  setup() {
    let mobile = ref(deviceDetection())
    let date: Date = new Date()
    let loading = ref(true)

    let greetings = computed(() => {
      if (date.getHours() >= 0 && date.getHours() < 12) {
        return "上午阳光明媚，祝你薪水翻倍🌞！"
      } else if (date.getHours() >= 12 && date.getHours() < 18) {
        return "下午小风娇好，愿你青春不老😃！"
      } else {
        return "折一根天使羽毛，愿拂去您的疲惫烦恼忧伤🌛！"
      }
    })

    const openDepot = (): void => {
      window.open("https://github.com/xiaoxian521/vue-pure-admin")
    }

    onMounted(() => {
      nextTick(() => {
        useEventListener("resize", () => {
          if (!brokenLine) return
          useTimeoutFn(() => {
            brokenLine.resize()
          }, 180)
        })
      })
    })

    tryOnUnmounted(() => {
      if (!brokenLine) return
      brokenLine.dispose()
      brokenLine = null
    })

    return {
      greetings,
      mobile,
      loading,
      openDepot,
    }
  },
}
</script>

<style lang="scss" scoped>
.welcome {
  width: 100%;
  height: 100%;
  margin-top: 1px;
  .top-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 120px;
    background: #fff;
    padding: 20px;
    border-bottom: 0.5px solid rgba($color: #ccc, $alpha: 0.3);
    .left-mark {
      display: flex;
      align-items: center;
      img {
        display: block;
        width: 72px;
        height: 72px;
        border-radius: 50%;
        margin-right: 10px;
        cursor: pointer;
      }
    }
  }
  .box-card {
    width: 80vw;
    margin: 10px auto;
    position: relative;
    #brokenLine {
      width: 100%;
      height: 50vh;
    }
  }
}
</style>
