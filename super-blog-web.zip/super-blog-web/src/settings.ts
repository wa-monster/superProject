export default {
  title: "spuer-blog-manage",

  fixedHeader: false,

  sidebarLogo: false,

  hiddenSideBar: false,
};
