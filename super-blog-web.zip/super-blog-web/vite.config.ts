import { resolve } from "path"
import { UserConfigExport, ConfigEnv } from "vite"
import vue from "@vitejs/plugin-vue"
import vueJsx from "@vitejs/plugin-vue-jsx"
import { loadEnv } from "./build/utils"
import { createProxy } from "./build/proxy"
import styleImport from "vite-plugin-style-import"

const pathResolve = (dir: string): any => {
  return resolve(__dirname, ".", dir)
}

const { VITE_PORT, VITE_PUBLIC_PATH, VITE_PROXY, VITE_OPEN } = loadEnv()

const alias: Record<string, string> = {
  "/@": pathResolve("src"),
}

const root: string = process.cwd()

export default ({ command }: ConfigEnv): UserConfigExport => {
  return {
    /**
     * 基本公共路径
     * /manages/ 可根据项目部署域名的后缀自行填写（全局搜/manages/替换）
     * @default '/'
     */
    base: process.env.NODE_ENV === "production" ? "/manages/" : VITE_PUBLIC_PATH,
    root,
    resolve: {
      alias,
    },
    // 服务端渲染
    server: {
      // 是否开启 https
      https: false,
      /**
       * 端口号
       * @default 3000
       */
      port: VITE_PORT,
      // 本地跨域代理
      proxy: createProxy(VITE_PROXY),
    },
    plugins: [
      vue(),
      vueJsx(),
      styleImport({
        libs: [
          // 按需加载element-plus
          {
            libraryName: "element-plus",
            esModule: true,
            ensureStyleFile: true,
            resolveStyle: (name) => {
              return `element-plus/lib/theme-chalk/${name}.css`
            },
            resolveComponent: (name) => {
              return `element-plus/lib/${name}`
            },
          },
          // 按需加载vxe-table
          {
            libraryName: "vxe-table",
            esModule: true,
            resolveComponent: (name) => `vxe-table/es/${name}`,
            resolveStyle: (name) => `vxe-table/es/${name}/style.css`,
          },
        ],
      }),
    ],
    optimizeDeps: {
      include: ["element-plus/lib/locale/lang/zh-cn", "element-plus/lib/locale/lang/en"],
    },
    build: {
      brotliSize: false,
      // 消除打包大小超过500kb警告
      chunkSizeWarningLimit: 2000,
    },
    define: {
      __INTLIFY_PROD_DEVTOOLS__: false,
    },
  }
}
